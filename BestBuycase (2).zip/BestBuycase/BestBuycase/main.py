import os
from flask import Flask, request, render_template, url_for 
from service import func
from flask_uploads import UploadSet, configure_uploads, IMAGES, patch_request_class

app = Flask(__name__)

app.config['UPLOADED_PHOTOS_DEST'] = os.getcwd()
app.config['UPLOAD_FOLDER'] = "uploaded_files"



photos = UploadSet('photos', IMAGES)
configure_uploads(app, photos)
patch_request_class(app)

app.debug = True


from flask import send_from_directory

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'],
                               filename)

@app.route('/')
def hello_world():
    return render_template('index.html')  


@app.route('/handle_data', methods=['POST'])
def handle_data():
    filename_data = request.files["photo"]
    filename = filename_data.filename 
    filename_data.save(os.path.join(app.config['UPLOAD_FOLDER'], filename_data.filename))
    clientname = request.form["clientname"]
    email = request.form["email"]
    description = request.form["description"]
    date = request.form["date"] 
    time = request.form["time"]
    return render_template('answer.html', clientname=clientname, email=email, description= description, date=date, time=time, url = url_for('uploaded_file', filename=filename))

if __name__ == '__main__':
    app.run()
