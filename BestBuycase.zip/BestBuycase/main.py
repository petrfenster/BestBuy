from flask import Flask, request, render_template
from service import func

app = Flask(__name__)
app.debug = True


@app.route('/')
def hello_world():
    return render_template('index.html')


@app.route('/handle_data', methods=['POST'])
def handle_data():
    clientname = request.form["clientname"]
    email = request.form["email"]
    description = request.form["description"]
    date = request.form["date"] 
    time = request.form["time"]
    answer = func(clientname, email, description, date, time) 
    return render_template('answer.html', answer=answer)


if __name__ == '__main__':
    app.run()
