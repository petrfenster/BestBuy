from flask import Flask, request, render_template
from service import func

app = Flask(__name__)
app.debug = True


@app.route('/')
def hello_world():
    return render_template('index.html')


@app.route('/handle_data', methods=['POST'])
def handle_data():
    clientname = request.form["clientname"]
    email = request.form["email"]
    imgofspace = request.form["imgofspace"]
    description = request.form["description"]
    date = request.form["date"] 
    time = request.form["time"]
    return render_template('answer.html', clientname=clientname, email=email, description= description, date=date, time=time, imgofspace=imgofspace)


if __name__ == '__main__':
    app.run()
